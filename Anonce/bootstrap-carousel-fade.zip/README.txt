A Pen created at CodePen.io. You can find this one at http://codepen.io/Ratia/pen/xGxdKV.

 Example Bootstrap Carousel using a fading technique.